#!/bin/bash
# RCAT LAMP Stack for CentOS
# https://github.com/gidcs/rcat-lamp
# vhost.sh

# Check if user is root
if [ $(id -u) != "0" ]; then
    echo "Error: You must be root to run this script, use sudo $0"
    exit 1
fi

function echoline {
	echo "========================================================================="
}

clear
echoline
echo "Add VirtualHost for RCAT,  Written by LKS "
echoline
echo "RCAT is a yum based solution to install LAMP development environment"
echo "For more information, please visit https://github.com/gidcs/rcat-lamp"
echo ""
echo "This script is a tool to add virtual host for Apache"
echoline

silent="0"

if [ "$1" != "--help" ]; then
	#set primary domain name
	while [ "$domain" = "" ]
	do
		read -p "Please input domain name,example(gidcs.net):" domain
		if [ "$domain" = "" ]; then
			echo "Error: Domain Name Can't be empty!!"
		else
			#check if conf exists
			if [ -f "/etc/httpd/conf.d/vhost_$domain.conf" ]; then
				tempdir=`find /home -name "$domain"`
				echo "Error: $domain exists!"
				#echo "Current directory: "$tempdir
				head -n 1 /etc/httpd/conf.d/vhost_$domain.conf | awk '{ print $2" "$3 }'
				exit
			fi
		fi
	done

	#get username
	while [ "$username" = "" ]
	do
		read -p "Please input username:" username
		if [[ "$username" =~ [^a-zA-Z0-9] ]]; then
                        echo "Error: Invalid Username!!"
                        username=""
                elif [ "$username" = "" ]; then
			echo "Error: Username Can't be empty!!"
		else
			ifexists=`cat /etc/passwd | awk -F':' -v username="$username" '{ if($1==username) printf $1 }'`
			if [ "$ifexists" != "" ]; then
				read -p "Username:$username exists! Use it? default:y (y/n)" use_username_before
				if [ -z "$use_username_before" ]; then
					use_username_before="y"
				fi
				if [ "$use_username_before" = "y" ]; then
					break
				fi
				username=""
			else
				while [ "$password" = "" ]
				do
					#get password
					read -p "Please input password:" password
					if [ "$password" = "" ]; then
						echo "Error: Password Can't be empty!!"	
					fi
				done
				break
			fi
		fi
	done

	#if not password
	if [ "$use_username_before" = "" ]; then
		if [ "$password" = "" ]; then
			use_username_before="y"
		fi
	fi
	echoline
	echo "domain=$domain"
	echo "username=$username"
	if [ "$password" != "" ]; then
		echo "password=$password"
	fi
	echoline
	
	#set more domain name
	if [ "$add_more_domainame" = "" ]; then
		read -p "Do you want to add more domain name? (y/n)" add_more_domainame
		if [ "$add_more_domainame" == 'y' ]; then
			echo "Type domainname,example(www.gidcs.net bbs.gidcs.net):"
			read moredomain
			if [ "$moredomain" == '' ]; then
				add_more_domainame=""
			fi
		fi
	fi
	if [ "$add_more_domainame" == 'y' ]; then
		echoline
        	echo domain list="$moredomain"
        	echoline
		moredomainame="$moredomain"
	fi

	#set directory
	userdir="/home/$username"
	vhostdir="/home/$username/$domain"
	logdir="/home/$username/.log"
	echoline
	echo User Directory="$userdir"
	echo Virtual Host Directory="$vhostdir"
	echo Log Directory="$logdir"
	echoline

	#set administrator email address
	if [ "$ServerAdmin" = "" ]; then
		read -p "Please input Administrator Email Address:" ServerAdmin
		if [ "$ServerAdmin" == "" ]; then
			echo "Administrator Email Address will set to webmaster@example.com!"
			ServerAdmin="webmaster@example.com"
		fi
	fi
	echoline
	echo Server Administrator Email="$ServerAdmin"
	echoline

	#set database name
	while [ "$database" = "" ]
	do
		read -p "Please input Database Name:" database
                if [[ "$database" =~ [^a-zA-Z0-9] ]]; then
                        echo "Error: Invalid Database Name!!"
                        database=""
                elif [ "$database" != "" ]; then
			database="${username}_${database}"
			if [ -d "/var/lib/mysql/${database}" ]; then
				echo "Error: $database exists!"
				database=""
			fi
		else
			echo "Error: Database Name Can't be empty!!"	
		fi
	done
	echoline
	echo Database Name="${database}"
	echoline

	if [ "$silent" == "0" ]; then
		echo ""
		echo "Press any key to start create virtul host..."
		read -n 1
	fi

if [ "$use_username_before" != "y" ]; then
echo "Create user......"
groupadd $username
useradd -g $username -n -M -s /sbin/nologin -d $userdir $username
mkdir -p $userdir
mkdir -p $logdir
chmod -R 755 $userdir
chown -R $username:$username $userdir
version=`grep -o "[0-9]" /etc/redhat-release | head -n1`
if [ "$version" -eq '5' ]; then
expect << EOF
spawn passwd ${username}
expect "New UNIX password:"
send "${password}\r"
expect "Retype new UNIX password:"
send "${password}\r"
expect eof;
EOF
else
expect << EOF
spawn passwd ${username}
expect "New password:"
send "${password}\r"
expect "Retype new password:"
send "${password}\r"
expect eof;
EOF
fi
else
echo "Use existent user......"
fi

echo "Create directory......"
mkdir -p $vhostdir
echo "Set permissions of Virtual Host directory......"
chmod -R 755 $vhostdir
chown -R $username:$username $vhostdir

echo "Create mysql database......"
mysqlrootpwd=`cat /etc/my.cnf | grep password | awk '{ printf $3 }'`
while [ "$mysqlrootpwd" = "" ]
do
	if [ "$mysqlrootpwd" = "" ]; then
		echo "Error: Cannot obtain MySQL root password from my.cnf"
		read -p "Please input mysql root password: " mysqlrootpwd
	else
		break
	fi
done
if [ "$use_username_before" = "y" ]; then
cat > /tmp/mysql_sec_script<<EOF
create database ${database};
grant all privileges on ${database}.* to $username@localhost ;
flush privileges;
EOF
else
cat > /tmp/mysql_sec_script<<EOF
create database ${database};
create user $username@localhost identified by '$password';
grant all privileges on ${database}.* to $username@localhost ;
flush privileges;
EOF
fi
mysql -u root -p$mysqlrootpwd -h localhost < /tmp/mysql_sec_script
rm -f /tmp/mysql_sec_script

cat >/etc/httpd/conf.d/vhost_$domain.conf<<eof
# DocumentRoot "$vhostdir"
<VirtualHost *:80>
	ServerAdmin $ServerAdmin
	DocumentRoot "$vhostdir/"
	ServerName $domain
	ErrorLog "$logdir/$domain-error_log"
	CustomLog "$logdir/$domain-access_log" common
	<Directory "$vhostdir/">
		Options +Includes -Indexes
		AllowOverride All
		<IfModule mod_authz_core.c>
			# Apache 2.4
			Require all granted
		</IfModule>
		<IfModule !mod_authz_core.c>
			# Apache 2.2
			Order Allow,Deny
			Allow from All
		</IfModule>
		RUidGid $username $username
	</Directory>
</VirtualHost>
eof

if [ "$add_more_domainame" == 'y' ]; then
sed -i "/ServerName/a\
ServerAlias $moredomainame" /etc/httpd/conf.d/vhost_$domain.conf
moredomain=( $moredomainame )
for i in "${moredomain[@]}"
do
	echo "# DocumentRoot "$vhostdir > /etc/httpd/conf.d/vhost_$i.conf
done
fi

echo "Restart Apache......"
service httpd restart

echo ""
read -p "Do you want to install wordpress? (y/n)" wordpress
if [ "$wordpress" == 'y' ]; then
	mkdir /tmp/wordpress.$$
	wget -O - http://wordpress.org/latest.tar.gz | \
		tar zxf - -C /tmp/wordpress.$$
	mv /tmp/wordpress.$$/wordpress/* "$vhostdir/"
	rm -rf /tmp/wordpress.$$
	chown -R $username:$username $vhostdir
else
	cd "$vhostdir/"
	cp /etc/rcat/index.zip "$vhostdir/"
	unzip -o index.zip
	rm -f index.zip
	chown -R $username:$username $vhostdir
	cd -
fi

echo ""
echoline
echo "Add VirtualHost for RCAT,  Written by LKS "
echoline
echo "For more information, please visit https://github.com/gidcs/rcat-lamp"
echo ""
echo "Your domain:$domain $moredomainame"
echo "Directory of $domain: $vhostdir"
echo "FTP Username: $username"
if [ "$use_username_before" = "y" ]; then
echo "FTP Password: you know it"
else
echo "FTP Password: $password"
fi
echo "MySQL Username: $username"
echo "MySQL Database: ${database}"
if [ "$use_username_before" = "y" ]; then
echo "MySQL Password: you know it"
else
echo "MySQL Password: $password"
fi
echoline

fi

